export const agents = [
  {
    name: "Tressa Winley",
    title: "Real estate associate broker",
    image: "./agents/agent1.webp",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam a velit fermentum, ultrices ligula sed, tincidunt est. Nullam vulputate sollicitudin nulla non pulvinar. In eget imperdiet magna."
  },
  {
    name: "Levon Tomson",
    title: "Real estate agent",
    image: "./agents/agent3.webp",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam a velit fermentum, ultrices ligula sed, tincidunt est. Nullam vulputate sollicitudin nulla non pulvinar. In eget imperdiet magna."
  },
  {
    name: "Linnet Cubin",
    title: "Real estate agent",
    image: "./agents/agent2.webp",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam a velit fermentum, ultrices ligula sed, tincidunt est. Nullam vulputate sollicitudin nulla non pulvinar. In eget imperdiet magna."
  },
  {
    name: "Roddy Epsley",
    title: "Real estate broker",
    image: "./agents/agent4.webp",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam a velit fermentum, ultrices ligula sed, tincidunt est. Nullam vulputate sollicitudin nulla non pulvinar. In eget imperdiet magna."
  }
];
