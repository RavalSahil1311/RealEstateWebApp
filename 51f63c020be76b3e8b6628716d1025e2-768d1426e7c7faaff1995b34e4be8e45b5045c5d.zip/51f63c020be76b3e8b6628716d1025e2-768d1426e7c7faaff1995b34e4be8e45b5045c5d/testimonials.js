export const testimonials = [
  {
    name: "Yovonnda Bostick",
    company: "Realmix",
    image: "./testimonials/testimonial1.webp",
    testimonial:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam a velit fermentum, ultrices ligula sed, tincidunt est. Nullam vulputate sollicitudin nulla non pulvinar. In eget imperdiet magna."
  },
  {
    name: "Fina Scallon",
    company: "Kamba",
    image: "./testimonials/testimonial3.webp",
    testimonial:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam a velit fermentum, ultrices ligula sed, tincidunt est. Nullam vulputate sollicitudin nulla non pulvinar. In eget imperdiet magna."
  },
  {
    name: "Ron Schonfeld",
    company: "Tagopia",
    image: "./testimonials/testimonial2.webp",
    testimonial:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam a velit fermentum, ultrices ligula sed, tincidunt est. Nullam vulputate sollicitudin nulla non pulvinar. In eget imperdiet magna."
  }
];
